const admin = require('firebase-admin'); // Menggunakan instance Firebase yang sudah diinisialisasi
const db = admin.firestore(); // Mendapatkan referensi ke Firestore

// Create a new user
exports.createUser = async (req, res) => {
  const { id, name, email } = req.body;

  // Validasi input
  if (!id || !name || !email) {
    return res.status(400).send({ error: 'All fields (id, name, email) are required' });
  }

  try {
    // Tambahkan data pengguna ke Firestore
    await db.collection('users').doc(id).set({
      name,
      email,
      created_at: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(`User created successfully with ID: ${id}`);
    res.status(201).send({ message: 'User created successfully', id });
  } catch (error) {
    console.error(`Error creating user: ${error.message}`);
    res.status(500).send({ error: error.message });
  }
};

// Get a user by ID
exports.getUser = async (req, res) => {
  const { id } = req.params;

  // Validasi input
  if (!id) {
    return res.status(400).send({ error: 'User ID is required' });
  }

  try {
    const doc = await db.collection('users').doc(id).get();

    if (!doc.exists) {
      console.log(`User with ID: ${id} not found`);
      return res.status(404).send({ message: 'User not found' });
    }

    // Ambil data pengguna
    const userData = doc.data();
    res.status(200).send({ id: doc.id, ...userData });
  } catch (error) {
    console.error(`Error fetching user with ID: ${id}, Error: ${error.message}`);
    res.status(500).send({ error: error.message });
  }
};
