const express = require('express');
const userController = require('../controllers/userController');

const router = express.Router();

// Routes for user operations
router.post('/users', userController.createUser); // Create user
router.get('/users/:id', userController.getUser); // Get user by ID

console.log('User routes loaded successfully');

module.exports = router;
