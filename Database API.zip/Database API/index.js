const express = require('express'); // Import Express framework
const admin = require('firebase-admin'); // Import Firebase Admin SDK
const bodyParser = require('body-parser'); // Import Body-Parser middleware

// Load Firebase service account key
const serviceAccount = require('./round-terminus-441316-h6-firebase-adminsdk-xrc5w-5740c66ebf.json');

// Initialize Firebase Admin SDK
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount), // Authenticate using the service account
    databaseURL: 'https://round-terminus-441316-h6.firebaseio.com', // Firestore database URL
  });
  console.log('Firebase initialized successfully');
} else {
  console.log('Firebase already initialized');
}

// Initialize Firestore
const db = admin.firestore();

// Express app
const app = express();

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Use user routes
const userRoutes = require('./routes/userRoutes'); // Pastikan jalur sesuai
app.use('/api', userRoutes);
console.log('Routes mounted at /api');


// Sample route for testing
app.get('/api/test', async (req, res) => {
  try {
    const testDoc = await db.collection('test').add({ message: 'Hello World!' });
    res.status(200).send({ message: 'Test document added', id: testDoc.id });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
